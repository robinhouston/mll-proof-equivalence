mll-proof-equivalence
=====================

The complexity of proof equivalence in multiplicative linear logic
