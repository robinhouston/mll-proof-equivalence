# (Possibly) related work

* [Linear lambda calculus and PTIME-completeness](http://www.cs.brandeis.edu/~mairson/Papers/jfp02.pdf)
